package com.trainingapps.carproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
