package com.trainingapps.carproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarprojectApplication.class, args);
	}

}
